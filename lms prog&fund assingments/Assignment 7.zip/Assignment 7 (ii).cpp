#include <iostream>

using namespace std;

int sum();

int main ()
{
    int num;
    num=sum();
    cout << num;
    return 0;
}

int sum(){
    int x=10,y=20,sum;
    sum=x+y;
    return sum;
}