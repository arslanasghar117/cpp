#include <iostream>

using namespace std;

void function(){
    cout<< "hello";
}

int main()
{
    function();
    return 0;
}