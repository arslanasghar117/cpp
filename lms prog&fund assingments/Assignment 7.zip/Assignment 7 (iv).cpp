#include <iostream>

using namespace std;

int function(int x);

int main()
{
    cout <<function(3);
    return 0;
}
int function(int x){
    return 5+x;
}