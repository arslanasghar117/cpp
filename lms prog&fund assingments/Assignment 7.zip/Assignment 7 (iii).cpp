#include <iostream>

using namespace std;

void function(string fname);

int main()
{
    function("arslan");
}

void function(string fname){
    
    cout<<"M."<<fname<<"\n";
    cout<<fname<<"asghar";
}