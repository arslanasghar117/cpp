#include<iostream>
using namespace std;
int main()
{
	int i;
	do
	{
	i++;
	if(i!=5)	
	cout << "Number is: "<<i<<endl;
    cout<<"Square is: "<<i*i<<endl<<endl;
	}
	while(i<10);
	return 0;
}
