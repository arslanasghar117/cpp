#include<iostream>
using namespace std;
int main()
{
	int i;
	while(i<10)
	{
	i++;
	if(i!=5)
	cout << "Number is: "<<i<<endl;
    cout<<"Square is: "<<i*i<<endl<<endl;
	}
	
	return 0;
}
