#include<iostream>
using namespace std;
int main()
{ 
int i,j=5;
	for (i = 1; i <=10; i++) {
    if (i != j) {
    cout << "Number is: "<<i<<endl;
    cout<<"Square is: "<<i*i<<endl<<endl;
    }
}
cout<<endl;
	return 0;
}
