//Function with no argument but return value
#include <iostream>
using namespace std;
int show();
int main()
{
    int s;
    s=show();
    if(s%2==0)
    {
    cout<<"You enter an even number.";
    }
    else
    {
    cout<<"You enter an odd number.";
    }
    return 0;
}
int show()
{
    int n;
    cout<<"Enter a number :";
    cin>>n;
    cout<<endl;
    return n;
}
