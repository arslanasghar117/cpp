//Function with argument but no return value
#include <iostream>
using namespace std;
void show(int a);
int main(void)
{
    int n;
    cout<<"Enter a number :";
    cin>>n;
    cout<<endl;
    show(n);


}
void show(int a)
{
    if(a%2==0)
    {
    cout<<"You enter an even number.";
    }
    else
    {
    cout<<"You enter an odd number.";
    }
}
