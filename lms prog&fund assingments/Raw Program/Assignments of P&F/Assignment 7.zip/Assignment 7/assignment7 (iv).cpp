//Function with argument and return value
#include<iostream>
using namespace std;
int show(int a);
int main()
{
    int b;
    cout<<"Enter a number :";
    cin>>b;
    cout<<endl;
    show(b);
    return 0;
}
int show(int a)
{
    if(a%2==0)
    cout<<"You enter an even number.";
    else
    cout<<"You enter an odd number.";
    return 0;
}
