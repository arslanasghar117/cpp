//Function with no argument and no return value
#include <iostream>
using namespace std;
void show();
int main()
{
    show();
    return 0;
}
void show(void)
{
    int n;
    cout<<"Enter a number :";
    cin>>n;
    cout<<endl;
    if(n%2==0)
    {
	cout<<"You enter an even number.";
	}
    else
    {
	cout<<"You enter an odd number.";
    }
}
