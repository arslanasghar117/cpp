//using do while loop
#include<iostream>
using namespace std;
int main()
{
	int i,j=5;
	do
	{
	i++;
	if(i!=j){
	cout << "Number is: "<<i<<endl;
    cout<<"Square is: "<<i*i<<endl<<endl;
	}
}
	while(i<10);
	return 0;
}
