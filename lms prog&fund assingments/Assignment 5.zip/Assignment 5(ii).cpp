//using while loop

#include<iostream>
using namespace std;
int main()
{
	int i,j=5;
	while(i<10)
	{
	i++;
	if(i!=j){
	cout << "Number is: "<<i<<endl;
    cout<<"Square is: "<<i*i<<endl<<endl;
	}
}
	return 0;
}
